<?php
include_once 'View/minNavigasjon.php';
?>
<br/><br/>
<div class="container">
    <br/><br/>
    <h4>Velkommen til TestingBank</h4>
    <p>Trykk her for å logge inn</p>
    <br/>
    <a href="View/loggInn.php" class="btn btn-success">Logg inn</a>
    <br/> <br/>
    <div id="feilMeldinger"></div>
</div>

